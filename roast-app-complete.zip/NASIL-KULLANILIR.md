# 📱 ROAST KAHVE UYGULAMASI - HEMEN KULLANIN!

## 🎉 Uygulamanız Hazır!

Tüm dosyalar oluşturuldu ve kullanıma hazır. Şimdi telefonunuzda kullanmak için şu adımları izleyin:

---

## 📲 HIZLI KURULUM (3 Adım)

### 1️⃣ Dosyaları Web'e Yükleyin

**EN KOLAY YOL - GitHub Pages (Ücretsiz, 2 dakika):**

1. GitHub.com'a gidin ve giriş yapın (hesabınız yoksa ücretsiz oluşturun)
2. Sağ üstte "+" > "New repository" tıklayın
3. Repository adı: `roast-coffee-app`
4. "Public" seçili olsun
5. "Create repository" tıklayın
6. "uploading an existing file" linkine tıklayın
7. Bu klasördeki TÜM dosyaları sürükleyip bırakın:
   - index.html
   - manifest.json  
   - sw.js
   - icon-72.png, icon-96.png, icon-128.png, icon-144.png, icon-152.png, icon-192.png, icon-384.png, icon-512.png

8. "Commit changes" tıklayın
9. Repository sayfasında "Settings" > "Pages" gidin
10. Source: "main" branch seçin > "Save"
11. 1-2 dakika bekleyin
12. Yeşil kutuda URL'niz görünecek: `https://kullaniciadi.github.io/roast-coffee-app/`

**ÖNEMLİ:** GitHub kullanıcı adınızı URL'de kullanın!

---

### 2️⃣ Telefonunuzda Açın

**iPhone/iPad (Safari):**
1. Safari'de GitHub Pages URL'nizi açın
2. Sayfa yüklenene kadar bekleyin
3. Ekranın altında "Ana Ekrana Ekle" popup'ı çıkacak

**Android (Chrome):**
1. Chrome'da GitHub Pages URL'nizi açın  
2. Sayfa yüklenene kadar bekleyin
3. "Yükle" veya "Ana ekrana ekle" popup'ı çıkacak

---

### 3️⃣ Ana Ekrana Ekleyin

**iPhone:**
1. Alt orta **Paylaş** butonuna (📤) dokunun
2. "Ana Ekrana Ekle" seçin
3. "Ekle" butonuna dokunun
4. ✅ Ana ekranınızda "Roast" ikonu var!

**Android:**
1. Ekrandaki **"Yükle"** popup'ına dokunun
2. Veya menü (⋮) > "Ana ekrana ekle"
3. "Ekle" veya "Yükle" dokunun
4. ✅ App drawer'ınızda "Roast" var!

---

## 🚀 ALTERNATİF HOSTING SEÇENEKLERİ

### Netlify (Daha Hızlı, Ücretsiz)

1. netlify.com'a gidin
2. "Add new site" > "Deploy manually"
3. Tüm dosyaları sürükle-bırak
4. Deploy tamamlanınca URL'niz hazır!
5. Telefonunuzda bu URL'i açın

### Vercel (Profesyonel, Ücretsiz)

1. vercel.com'a gidin
2. "New Project" > "Continue with GitHub"
3. Repository'nizi seçin
4. Deploy!
5. URL'niz hazır

### Kendi Sunucunuz

Eğer web hosting'iniz varsa:
- Tüm dosyaları `public_html` veya `www` klasörüne yükleyin
- HTTPS olmalı (PWA için zorunlu)
- URL'nizi telefonunuzda açın

---

## ✅ BAŞARILI KURULUM KONTROL LİSTESİ

Uygulama doğru kurulduysa:

- [ ] Ana ekranda "Roast" ikonu görünüyor
- [ ] İkona dokunduğumda tarayıcı UI olmadan açılıyor
- [ ] Tam ekran çalışıyor (adres çubuğu yok)
- [ ] Offline modda da açılıyor
- [ ] Hızlı yükleniyor (anında)

---

## 🎯 ŞU AN NE YAPMAM LAZIM?

1. ✅ Dosyaları indirin (zaten indirdiniz)
2. ⏳ GitHub Pages'e yükleyin (yukarıdaki adımlar)
3. ⏳ Telefonunuzda URL'i açın
4. ⏳ Ana ekrana ekleyin
5. 🎉 Roast'ı kullanmaya başlayın!

---

## 💡 İPUCU

**GitHub hesabınız yoksa:**
- github.com/signup adresinden ücretsiz hesap açın
- 5 dakika sürer
- Kredi kartı gerektirmez

**Netlify tercih ederseniz:**
- Daha hızlı (drag & drop)
- GitHub hesabı gerektirmez
- Anında deploy

---

## 🐛 SORUN MU YAŞIYORSUNUZ?

**"Ana ekrana ekle" çıkmıyor:**
- ✅ HTTPS URL kullanıyor musunuz? (GitHub Pages otomatik HTTPS)
- ✅ iOS'ta Safari kullanıyor musunuz? (Chrome değil)
- ✅ Sayfa tamamen yüklendi mi?

**İkonlar görünmüyor:**
- icon-*.png dosyalarını yüklemeyi unutmayın
- Hepsini birlikte yükleyin

**Offline çalışmıyor:**
- İlk açılışta internet bağlantısı olmalı
- Service Worker yüklenmesi için sayfa yenileyin

---

## 📞 HIZLI YARDIM

1. Tüm dosyaları yüklediniz mi? (11 dosya)
2. HTTPS URL'niz var mı?
3. Telefonunuzda doğru tarayıcıyı kullanıyor musunuz?
   - iOS: Safari ✅ Chrome ❌
   - Android: Chrome ✅ Firefox ✅

---

## 🎊 TEBRİKLER!

Uygulamanız profesyonel bir PWA olarak hazır:
- Native app gibi çalışıyor
- App store gerektirmiyor
- Otomatik güncellemeler
- Offline desteği
- Hızlı performans

**Artık telefonunuzda Roast kahve uygulamasını kullanabilirsiniz!** ☕

---

**Yaratıcı:** Claude (Anthropic)
**Tarih:** 22 Şubat 2026
**Lisans:** Kişisel kullanım için ücretsiz
