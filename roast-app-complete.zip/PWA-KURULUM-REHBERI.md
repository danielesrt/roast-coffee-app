# 📱 Roast - Kahve Keşif Uygulaması
## Progressive Web App (PWA) Kurulum Rehberi

Bu rehber, Roast kahve uygulamasını telefonunuzda native app gibi kullanmanız için gerekli adımları açıklar.

---

## 📦 Dosyalar

Uygulamanızı PWA olarak çalıştırmak için şu dosyalar gereklidir:

- `coffee-app.html` - Ana uygulama dosyası
- `manifest.json` - PWA yapılandırması
- `sw.js` - Service Worker (offline çalışma)
- `icon-generator.html` - Uygulama ikonları oluşturucu
- `icon-*.png` - Uygulama ikonları (72px - 512px arası)

---

## 🚀 Kurulum Adımları

### Adım 1: Dosyaları Sunucuya Yükleme

Tüm dosyaları bir web sunucusuna yükleyin:

**Seçenek A - GitHub Pages (Ücretsiz):**
1. GitHub'da yeni bir repository oluşturun
2. Tüm dosyaları repository'ye yükleyin
3. Settings > Pages > Source: main branch seçin
4. URL'niz: `https://kullaniciadi.github.io/roast/`

**Seçenek B - Netlify/Vercel (Ücretsiz):**
1. netlify.com veya vercel.com'a kaydolun
2. "New Site from Git" veya "Import Project" seçin
3. Dosyaları sürükleyip bırakın
4. Deploy edin

**Seçenek C - Kendi Sunucunuz:**
- Dosyaları sunucunuzun public_html veya www klasörüne yükleyin
- HTTPS zorunludur (PWA için)

---

### Adım 2: Uygulama İkonlarını Oluşturma

1. `icon-generator.html` dosyasını tarayıcıda açın
2. "Tüm İkonları İndir" butonuna tıklayın
3. İndirilen ikonları diğer dosyalarla aynı klasöre koyun

**Manuel ikon oluşturma:**
- Kendi logonuzu kullanmak isterseniz:
- 512x512px PNG dosyası oluşturun
- Online araçlarla (realfavicongenerator.net) tüm boyutları oluşturun

---

### Adım 3: Ana Ekrana Ekleme

#### 📱 iOS (iPhone/iPad)

1. Safari ile uygulamanızın URL'sini açın
2. Alt orta **Paylaş** butonuna (📤) dokunun
3. Aşağı kaydırın ve **"Ana Ekrana Ekle"** seçin
4. İsmi düzenleyin (isteğe bağlı): "Roast"
5. **"Ekle"** butonuna dokunun
6. ✅ Uygulama ana ekranınızda!

**iOS Notları:**
- Safari dışındaki tarayıcılarda PWA kurulumu çalışmaz
- iOS 16.4+ gereklidir (tam PWA desteği için)
- Bildirimler iOS'ta sınırlıdır

#### 🤖 Android

**Chrome/Edge/Samsung Internet:**

1. Uygulamanızın URL'sini açın
2. Sağ üst menüden (⋮) **"Ana ekrana ekle"** seçin
3. Ya da ekranda çıkan **"Yükle"** popup'ına tıklayın
4. İsmi onaylayın
5. **"Ekle"** veya **"Yükle"** butonuna dokunun
6. ✅ Uygulama app drawer'ınızda!

**Manuel yöntem:**
1. Chrome menü (⋮) > Settings > Add to Home Screen
2. İsmi düzenleyin
3. Add tuşuna basın

**Android Notları:**
- Chrome 68+ gereklidir
- Standalone modda çalışır (tam ekran, browser UI yok)
- Push notification desteği var

---

## ✨ PWA Özellikleri

Uygulamanız şu özelliklere sahip:

### ✅ Ana Ekran İkonu
- Telefonunuzun ana ekranında kendi ikonuyla görünür
- Native app gibi açılır

### ✅ Standalone Mod
- Tarayıcı adres çubuğu olmadan çalışır
- Tam ekran deneyimi
- Native app hissi

### ✅ Offline Çalışma
- İnternet olmadan temel özellikler çalışır
- Service Worker cache kullanır
- Son görüntülenen sayfalar kaydedilir

### ✅ Fast Loading
- Anında açılış
- Cached assets
- Progressive enhancement

### ✅ Splash Screen
- iOS ve Android'de açılış ekranı
- Marka renkleri (kahverengi tema)

### ✅ Status Bar Styling
- iOS'ta status bar rengi ayarlanmış
- Android'de theme color aktif

---

## 🔧 Özelleştirme

### Renkleri Değiştirme

`manifest.json` içinde:
```json
"theme_color": "#3E2723",      // Status bar rengi
"background_color": "#F5E6D3"  // Splash screen arka plan
```

### İsim Değiştirme

`manifest.json` içinde:
```json
"name": "Sizin Uygulama İsminiz",
"short_name": "Kısa İsim"
```

### Start URL Değiştirme

`manifest.json` içinde:
```json
"start_url": "/istediginiz-sayfa.html"
```

---

## 🐛 Sorun Giderme

### "Ana ekrana ekle" seçeneği görünmüyor

**Çözüm:**
- ✅ HTTPS kullanıyor musunuz? (Zorunlu)
- ✅ manifest.json doğru yolda mı?
- ✅ Service Worker kayıtlı mı? (DevTools > Application > Service Workers)
- ✅ iOS'ta Safari kullanıyor musunuz?

### Offline çalışmıyor

**Çözüm:**
1. DevTools > Application > Service Workers
2. "Update on reload" işaretleyin
3. Sayfayı yenileyin
4. Console'da hata var mı kontrol edin

### İkon görünmüyor

**Çözüm:**
- Icon dosyalarının doğru konumda olduğundan emin olun
- manifest.json'daki icon path'leri kontrol edin
- Cache'i temizleyin ve yeniden yükleyin
- DevTools > Application > Manifest - ikonları görebilir misiniz?

### iOS'ta tam ekran olmuyor

**Çözüm:**
- `apple-mobile-web-app-capable` meta tag'i var mı?
- Safari'den kurulum yapıldı mı?
- Ana ekrandan açılıyor mu? (Safari'den değil)

---

## 📊 PWA Test Etme

### Chrome DevTools

1. F12 veya Cmd+Opt+I ile DevTools'u açın
2. **Lighthouse** sekmesine gidin
3. Categories: "Progressive Web App" seçin
4. "Generate report" tıklayın
5. 90+ puan hedefleyin

### Online Araçlar

- [web.dev/measure](https://web.dev/measure/) - Kapsamlı PWA testi
- [PWABuilder](https://www.pwabuilder.com/) - PWA analizi
- [Manifest Validator](https://manifest-validator.appspot.com/) - Manifest kontrolü

---

## 🔒 Güvenlik

PWA'lar için:
- ✅ **HTTPS zorunludur** - Şifreleme gerekli
- ✅ Service Worker güvenlik politikaları
- ✅ Same-origin policy
- ✅ Permissions API (konum, kamera vb.)

---

## 📚 Ek Kaynaklar

### Resmi Dokümantasyon
- [MDN - Progressive Web Apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Google PWA Guide](https://web.dev/progressive-web-apps/)
- [Apple PWA Documentation](https://developer.apple.com/documentation/webkit/creating_progressive_web_apps_for_ios)

### Araçlar
- [PWA Asset Generator](https://github.com/elegantapp/pwa-asset-generator) - İkon/splash oluşturma
- [Workbox](https://developers.google.com/web/tools/workbox) - Service Worker kütüphanesi
- [PWA Studio](https://pwastudio.com/) - PWA geliştirme araçları

---

## 📞 Destek

Sorun yaşarsanız:

1. **Browser Console kontrol edin:**
   - F12 > Console
   - Hata mesajları var mı?

2. **Service Worker durumunu kontrol edin:**
   - DevTools > Application > Service Workers
   - Status: "Activated and running" olmalı

3. **Manifest doğrulayın:**
   - DevTools > Application > Manifest
   - Tüm alanlar dolu mu?

4. **Cache'i temizleyin:**
   - DevTools > Application > Clear Storage
   - "Clear site data" tıklayın
   - Sayfayı yenileyin

---

## 🎉 Başarılı Kurulum Kontrolü

Uygulama doğru kurulduysa:

- ✅ Ana ekranda "Roast" ikonu var
- ✅ Tıkladığınızda browser UI olmadan açılıyor
- ✅ Offline modda temel özellikler çalışıyor
- ✅ Hızlı açılış (instant loading)
- ✅ Status bar uygulama renginizde

**Tebrikler! 🎊 Artık native app deneyimine sahipsiniz.**

---

## 📝 Notlar

- PWA'lar app store'dan kurulmuyor (doğrudan web'den)
- Otomatik güncellemeler Service Worker ile
- İnternet olmadan sınırlı özellikler
- iOS kısıtlamaları var (push notifications vb.)
- Android'de tam PWA desteği

---

**Versiyon:** 1.0.0  
**Son Güncelleme:** 22 Şubat 2026  
**Platform:** iOS 16.4+ / Android Chrome 68+  
**Lisans:** MIT

---

İyi kahveler! ☕
