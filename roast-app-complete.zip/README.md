# ☕ Roast - Kahve Keşif Uygulaması (PWA)

![Roast Logo](icon-192.png)

## 🎉 Hoş Geldiniz!

Roast kahve uygulamanız **tamamen hazır** ve telefonunuzda kullanıma hazır!

---

## 📦 İndirdiğiniz Dosyalar

Bu klasörde şu dosyalar var:

### Ana Uygulama Dosyaları
- `index.html` - Ana sayfa
- `manifest.json` - PWA yapılandırması  
- `sw.js` - Service Worker (offline çalışma)

### Uygulama İkonları (8 adet)
- `icon-72.png`
- `icon-96.png`
- `icon-128.png`
- `icon-144.png`
- `icon-152.png`
- `icon-192.png`
- `icon-384.png`
- `icon-512.png`

### Dokümantasyon
- `README.md` - Bu dosya
- `NASIL-KULLANILIR.md` - Hızlı başlangıç rehberi
- `PWA-KURULUM-REHBERI.md` - Detaylı teknik rehber

---

## 🚀 HEMEN BAŞLAYIN (3 Adım)

### 1. Dosyaları GitHub Pages'e Yükleyin

1. github.com'a gidin (ücretsiz hesap açın)
2. Yeni repository oluşturun: "roast-app"
3. Tüm dosyaları yükleyin (drag & drop)
4. Settings > Pages > main branch seçin
5. URL'niz hazır: `https://kullaniciadi.github.io/roast-app/`

### 2. Telefonunuzda Açın

- **iPhone:** Safari ile URL'i açın
- **Android:** Chrome ile URL'i açın

### 3. Ana Ekrana Ekleyin

- **iPhone:** Paylaş (📤) > Ana Ekrana Ekle
- **Android:** Menü (⋮) > Ana ekrana ekle

✅ **Tamamlandı!** Artık native app gibi kullanabilirsiniz.

---

## 📱 Özellikler

✨ **Native App Deneyimi**
- Tam ekran çalışma
- Browser UI olmadan
- Ana ekran ikonu
- Splash screen

⚡ **Performans**
- Anında yükleme
- Offline çalışma
- Cache desteği
- Hızlı navigasyon

🎨 **Tasarım**
- Minimalist & şık
- Responsive (mobil/tablet/masaüstü)
- Smooth animasyonlar
- Özel tipografi (Cormorant + DM Sans)

---

## 💡 Hosting Seçenekleri

### GitHub Pages (Önerilen - Ücretsiz)
- ✅ Kolay kurulum
- ✅ Otomatik HTTPS
- ✅ Ücretsiz
- ⏱️ 2-5 dakika

### Netlify (En Hızlı - Ücretsiz)
- ✅ Drag & drop
- ✅ Anında deploy
- ✅ Otomatik güncelleme
- ⏱️ 1 dakika

### Vercel (Profesyonel - Ücretsiz)
- ✅ GitHub entegrasyonu
- ✅ Hızlı CDN
- ✅ Analytics
- ⏱️ 2-3 dakika

---

## 🎯 Sonraki Adımlar

1. ✅ `NASIL-KULLANILIR.md` dosyasını okuyun
2. ✅ Dosyaları web'e yükleyin
3. ✅ Telefonunuzda test edin
4. ✅ Arkadaşlarınızla paylaşın!

---

## 🐛 Sorun mu var?

**Ana ekrana ekle görünmüyor:**
- HTTPS kullanıyor musunuz? (GitHub Pages otomatik)
- iOS'ta Safari kullanıyor musunuz?

**Offline çalışmıyor:**
- İlk yüklemede internet gerekli
- Service Worker aktif mi kontrol edin

**İkonlar yüklenmiyor:**
- Tüm icon-*.png dosyalarını yüklemeyi unutmayın

Detaylı sorun giderme: `PWA-KURULUM-REHBERI.md`

---

## 🎨 Tasarım Sistemi

Uygulama Apple Human Interface Guidelines'a uygun olarak tasarlandı:

**Renkler:**
- Espresso: #3E2723 (ana renk)
- Latte: #F5E6D3 (arka plan)
- Crema: #C89F6C (vurgular)

**Tipografi:**
- Display: Cormorant (serif, zarif)
- Body: DM Sans (modern, okunaklı)

**Boşluk:**
- 8px taban birim sistemi
- Tutarlı padding/margin

---

## 📄 Lisans

Kişisel kullanım için ücretsiz.

---

## 🙏 Teşekkürler

Roast kahve uygulamasını kullandığınız için teşekkürler!

İyi kahveler! ☕

---

**Versiyon:** 1.0.0  
**Tarih:** 22 Şubat 2026  
**Platform:** iOS 16.4+ / Android Chrome 68+
